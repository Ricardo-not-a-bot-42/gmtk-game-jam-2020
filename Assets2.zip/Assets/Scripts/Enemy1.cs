﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy1 : MonoBehaviour
{
    
    
    public float speed;
    float SpeedMultiplier;
    float EndSpeed=0;
    float Explode;
    public GameObject DestroyParticles;
    public GameObject BombEnemy;
    

   
    void Start()
    {
       
        Explode = Random.Range(0, 20);
        

    }

    public void Mult(float TimeBTW)
    {
        
        EndSpeed = TimeBTW;
        print("time");
        print(EndSpeed);
        
        
    }

    
    void Update()
    {
        SpeedMultiplier = speed + EndSpeed * 4; 
        transform.Translate(Vector2.down * SpeedMultiplier * Time.deltaTime);

    }
    void OnTriggerEnter2D(Collider2D hitObject)
    {
        if (hitObject.tag == "char")
        {
           
            Destroy(gameObject);
            Instantiate(DestroyParticles, transform.position, Quaternion.identity);
        }
        if (hitObject.tag == "Floor" && Explode != 12)
        {
           
            Destroy(gameObject);
            Instantiate(DestroyParticles, transform.position, Quaternion.identity);
        }
        if (hitObject.tag == "Floor" && Explode == 12)
        {
            
            Destroy(gameObject);
            Instantiate(BombEnemy, transform.position, Quaternion.identity);

        }
        if (hitObject.tag == "SafeSpot")
        {
            
            Destroy(gameObject);
            Instantiate(DestroyParticles, transform.position, Quaternion.identity);
        }

    }
    
}
    
