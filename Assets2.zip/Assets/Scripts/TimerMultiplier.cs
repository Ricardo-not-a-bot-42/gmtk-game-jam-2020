﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimerMultiplier : MonoBehaviour
{

    float timeMultiplier = 0;
    private TimeHandler timeHandler;

    // Start is called before the first frame update

    void Awake()
    {
        timeHandler = FindObjectOfType<TimeHandler>();
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "SafeSpot" && timeMultiplier == 0)
        {Destroy(gameObject);
            timeMultiplier = 1;
            
            timeHandler.Multiplier(timeMultiplier);
            // insert animation
            
        }

    }
}
