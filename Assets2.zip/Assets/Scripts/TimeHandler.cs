﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeHandler : MonoBehaviour
{
    public float TimeBTW = 1;
    private Enemy1[] enemies;
        

   

    public void Multiplier(float timeMultiplier)
    {
        TimeBTW = TimeBTW + timeMultiplier;
        //print(TimeBTW);
        timeMultiplier = 0;
    }

    void Awake()
    {
        enemies = FindObjectsOfType<Enemy1>();
    }

    
    void Update()
    {
        foreach (Enemy1 enemy in enemies)
        {
            enemy.Mult(TimeBTW);
        }
        
    }
}
